<?php

namespace App\Http\Controllers;
use App\Models\Contrat;
use App\Models\Employee;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use PDF;


class employeController extends Controller
{

    public function creerEmploye(Request $request)
    {

        // Validation des données du formulaire
        $validatedData = $request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'genre' => 'required|string',
            'profession' => 'required|string|max:255',
            'departement' => 'required|string|max:255',
            'service' => 'required|string|max:255',
            'numcnss' => 'nullable|string|max:255',
            'tel' => 'required|string|max:20',
            'email' => 'required|email|unique:employees,email',
            'photo' => 'required|image|max:2048',
            'date_debut_contrat' => 'required|date',
            'date_fin_contrat' => 'required|date',
            'type_contrat' => 'required|string',
            'salaire' => 'required|numeric',
            'statut' => 'nullable|string',
           ' contrat_pdf'=> 'nullable|string',
        ]);

        // Enregistrement de l'employé
        $employee = new Employee();
        $employee->nom = $validatedData['nom'];
        $employee->prenom = $validatedData['prenom'];
        $employee->genre = $validatedData['genre'];
        $employee->profession = $validatedData['profession'];
        $employee->departement = $validatedData['departement'];
        $employee->service = $validatedData['service'];
        $employee->numcnss = $validatedData['numcnss'];
        $employee->tel = $validatedData['tel'];
        $employee->email = $validatedData['email'];

        $employee->statut = $validatedData['statut'] ?? null;
        $photo = $request->file('photo');
        $photoPath = $photo->store('employees', 'public');
        $employee->photo = $photoPath;

        $employee->save();
        if (!empty($employee->id)) {
            Employee::where('id', $employee->id)->update([
                'matricule' => 'GG_RH' . $employee->id,
            ]);
            $contrat = new Contrat();
            $contrat->date_debut_contrat = $validatedData['date_debut_contrat'];
            $contrat->date_fin_contrat = $validatedData['date_fin_contrat'];
            $contrat->type_contrat = $validatedData['type_contrat'];
            $contrat->salaire = $validatedData['salaire'];
            $contrat->id_employe = $employee->id;
            $contrat_pdf = $request->file('contrat_pdf');
            $contrat_pdfPath = $contrat_pdf->store('employees', 'public');
            $contrat->contrat_pdf = $contrat_pdfPath;

            $contrat->save();

        } else {
            return redirect()->route('formulaireAjoutemploye')->with('error', 'Une erreur s\'est produite');
        }



        /* return response()->json([
             'statut' => true,
             'body' => $employee
         ]);*/

        return redirect()->route('listeemploye')->with('success', 'Employé ajouté avec succès.');


    }
    public function listeEmployes()
    {
        $employees = Employee::where(function ($query) {
            $query->where('statut', '!=', '1')
                ->orWhereNull('statut');
        })->withCount(['contrats', 'fiche_de_paies', 'courriers'])->get();

        return view('employes.liste', compact('employees'));
        /*  return response()->json([
                'statut' => true,
                'body' => $employees
            ]);*/

    }
    
    public function formulaireAjoutemploye()
    {

        return view('employes.ajout');


    }



    public function edite_employe($id)
    {
        $employe = Employee::find($id);
        return view('employes.modifier', compact('employe'));

        /*return response()->json([
            'statut' => true,
            'body' => $employee
        ]);*/
    }

    public function modifier_employe(Request $request, $id)
    {
        $employe = Employee::find($id);
        $validatedData = $request->validate([
            /*'nom' => 'required',
            'prenom' => 'required',
            'genre' => 'required',
            'profession' => 'required',
            'matricule' => 'required',
            'tel' => 'required',
            'email' => 'required|email',
            'photo' => 'required|image|max:2048',*/
            'date_embauche' => 'required',
            'date_debut_contrat' => 'required',
            'date_fin_contrat' => 'required',
            'type_contrat' => 'required',
            'salaire' => 'required',
            'statut' => 'nullable|string',
           ' contrat_pdf'=> 'nullable|string',

        ]);

        if (!empty($employe)) {
            $contrat = new Contrat();
            $contrat->date_debut_contrat = $validatedData['date_debut_contrat'];
            $contrat->date_fin_contrat = $validatedData['date_fin_contrat'];
            $contrat->type_contrat = $validatedData['type_contrat'];
            $contrat->salaire = $validatedData['salaire'];
            $contrat->id_employe = $employe->id;
            $contrat_pdf = $request->file('contrat_pdf');
            $contrat_pdfPath = $contrat_pdf->store('employees', 'public');
            $contrat->contrat_pdf = $contrat_pdfPath;

            $contrat->save();

        } else {
            return redirect()->route('edite_employe')->with('error', 'Une erreur s\'est produite');
        }

        return redirect()->route('listeemploye')->with('sucess', 'nouveau contrat etablis');

    }


    public function recherche_employe($matricule)
    {
        $employees = Employee::where('matricule', $matricule)->first();

        if ($employees) {
            return  redirect()->route('listeemploye', compact('employees'));
        } else {
            return redirect()->route('listeemploye')->with('echoue', 'Archivage  non effectué');
        }
    }

    public function archiver_employe($id)
    {
        $employee = Employee::find($id);

        $employee->statut = 1;
        $employee->save();

        if ($employee) {
            return redirect()->route('listeemploye')->with('success', 'Employé archivé.');

        } else {
            return redirect()->route('listeemploye')->with('echoue', 'Archivage  non effectué');
        }


    }

    public function listeEmployesArchive()
    {
        $employees = Employee::where('statut', '=', 1)->get();
        return view('employes.listeArchive', compact('employees'));

    }
    public function genererContrat(Employee $employee, $id)
    {

        $employee = Employee::where('id', $id)->first();

        if ($employee) {
            $contrats = Contrat::where('id_employe', $employee->id)->orderBy('created_at', 'desc')->take(1)->get()->toArray();

            //dd($contrats->toArray());
        }

        //$employee = Employee::with('contrats' )->find($id);


        return view('employes.contrat', compact('employee', 'contrats'));


    }


    public function consulterEmployer($id)
    {

        $employee = Employee::with('fiche_de_paies', 'courriers', 'contrats')->find($id);

        $infocontrat = Contrat::where('id_employe', $employee->id)->orderBy('created_at', 'desc')->take(1)->get()->toArray();




        return view('employes.consulter', compact('employee', 'infocontrat'));


    }
   

    public function telecharger_contrat($id)
    {
        $contrat = Contrat::findOrFail($id);
    
        
        $filePath = storage_path('app/public/' . $contrat->contrat_pdf); 
    
       
        if (file_exists($filePath)) {
            
            $filename = basename($contrat->contrat_pdf);
            
          
            $filename = preg_replace('/[\/\\\]/', '', $filename);
    
            return Response::download($filePath, $filename); 
        }
    
        return redirect()->back()->with('error', 'Fichier non trouvé.');
    }
































}
