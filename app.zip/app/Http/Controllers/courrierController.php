<?php

namespace App\Http\Controllers;

use App\Models\Courrier;
use App\Models\Employee;
use Illuminate\Http\Request;

class courrierController extends Controller
{
 

    public function sanction(Request $request)
    {
        // Validation des données du formulaire
        $validatedData = $request->validate([
            'date_du_courrier' => 'required',
            'type_de_courrier' => 'required',
            'date_debut' => 'nullable|date',
            'date_fin' => 'nullable|date',
            'motif' => 'nullable|string',
            'type_de_sanction'=>'nullable|string',
            'mesure_corrective'=>'nullable|string',
            'statut' => 'nullable|string',
            'id_employe' => 'required',

        ]);
       

        
        $courrier = new Courrier();
        $courrier->date_du_courrier = $validatedData['date_du_courrier'];
        $courrier->type_de_courrier = $validatedData['type_de_courrier'];
        $courrier->date_debut = $validatedData['date_debut']?? null;
        $courrier->date_fin = $validatedData['date_fin']?? null;
        $courrier->motif = $validatedData['motif']?? null;
        $courrier->type_de_sanction = $validatedData['type_de_sanction']?? null;
        $courrier->mesure_corrective = $validatedData['mesure_corrective']?? null;
        $courrier->statut = $validatedData['statut'] ?? null;
        $courrier->id_employe = $validatedData['id_employe'];
        
        $courrier->save();
       /* if ($courrier) {

            return response()->json([
                'statut' => true,
                'body' => $courrier
            ]);
        } else {
            return response()->json([
                'statut' => false,
                'message' => 'envois impossible'
            ]);
        }*/


        return redirect()->route('dashboard')->with('success', 'sanction envoyé avec succès.');
    }


    public function formulaireAjoutSanction($id)
      {
        $employe = Employee::find($id);
        return view('courrier.ajout', compact('employe'));
      }
      public function formAvenant($id)
      {
        $employe = Employee::find($id);
        return view('courrier.avenant', compact('employe'));
    
       
       
      }

      
   
      public function listeFiche_de_courrrier()
      {
       $courriers = Courrier::where(function($query) {
           $query->where('statut', '!=', 'refusé')
                 ->orWhereNull('statut')->orWhere('statut','!=','accepté');
       })->get();
           return view('courrier.liste', compact('courriers'));
          
      }
      public function accepter_Courrier($id)
    {
        $courriers = Courrier::find($id);

        $courriers->statut = 'accepté';
        $courriers->save();

            return redirect()->route('dashboard')->with('success', 'demande accepté.');

      


    }
    public function refuser_Courrier($id)
    {
        $courriers = Courrier::find($id);

        $courriers->statut = 'refusé';
        $courriers->save();
            return redirect()->route('dashboard')->with('success', 'demande refusé.');



    }






}
