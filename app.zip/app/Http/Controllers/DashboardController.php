<?php
namespace App\Http\Controllers;

use App\Models\Courrier;
use App\Models\Employee;
use App\Models\Fiche_de_paie;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class DashboardController extends Controller
{

    public function index()
    {
        $notifications = auth()->user()->notifications;
        $nombreEmployes = Employee::where('statut', '!=', 1)->count();
        $nombrefiches_de_paie = Fiche_de_paie::all()->count();
        $nombreCourriers = Courrier::all()->count();
        $courrier_par_employe = Employee::withCount('courriers')->get();
        $fiches_de_paie_par_employe = Employee::withCount('fiche_de_paies')->get();

        $today = Carbon::now();
        $endDate = $today->copy()->addMonth();
        $employes = Employee::whereHas('contrats', function ($query) use ($today, $endDate) {
            $query->whereBetween('date_fin_contrat', [$today, $endDate]);
        })->with('contrats')->get();

        $courriers = Courrier::with('employes')->where(function($query) {
            $query->where(function($q) {
                $q->where('type_de_courrier', '=', 'absence')
                  ->orWhere('type_de_courrier', '=', 'congé');
            })
            ->where(function($q) {
                $q->where('statut', '!=', 'accepté')
                  ->where('statut', '!=', 'refusé');
            })
            ->orWhere(function($q) {
                $q->where('type_de_courrier', '=', 'absence')
                  ->orWhere('type_de_courrier', '=', 'congé')
                  ->whereNull('statut');
            });
        })->get();
        return view('dashboard', compact('notifications', 'nombreEmployes', 'nombreCourriers', 'courrier_par_employe', 'fiches_de_paie_par_employe', 'nombrefiches_de_paie', 'employes','courriers'));
    }
}