<?php

namespace App\Http\Controllers;

use App\Models\Contrat;
use App\Models\Courrier;
use App\Models\Employee;
use App\Models\Fiche_de_paie;
use Illuminate\Http\Request;

class mobileController extends Controller
{
    public function connexion(Request $request)
    {
         $matricule = $request->input('matricule');
         $email = $request->input('email');
    
        $employe = Employee::where('matricule',$matricule)
            ->where('email', $email)
            ->first();
        $employe->photo = asset('storage/' . $employe->photo);
    
        if ($employe) {
            return response()->json([
                'statut' => true,
                'employe' => $employe
            ]);
        } else {
            return response()->json([
                'statut' =>false,             
                'message' => 'dossier vide'], 401);
        }
    }
    public function consulterContrat($id)
    {
            $contrat = Contrat::where('id_employe',$id)->orderBy('created_at','desc')->get()->toArray();
            if ($contrat) {
                return response()->json([
                    'statut' => true,
                    'contrat' => $contrat
                ]);
            }  elseif($contrat==''){
                return response()->json([
                    'statut' => true,
                    'message' => 'aucun bulletin'
                ]);}
            else {
                return response()->json([
                    'statut' =>false,             
                    'message' => 'dossier vide'], 401);
            }           
     }
     public function consulterbulletin($id)
     {
             $bulletin = Fiche_de_paie::where('id_employe',$id)->orderBy('created_at','desc')->get()->toArray();
             if ($bulletin) {
                 return response()->json([
                     'statut' => true,
                     'bulletin' => $bulletin
                 ]);
             } elseif($bulletin==''){
                return response()->json([
                    'statut' => true,
                    'message' => 'aucun bulletin'
                ]);}
             else {
                 return response()->json([
                     'statut' =>false,             
                     'message' => 'dossier vide'], 401);
             }           
      }
      public function consultercourrier($id)
      {
              $courrier = Courrier::where('id_employe',$id)->orderBy('created_at','desc')->get()->toArray();
              if ($courrier) {
                  return response()->json([
                      'statut' => true,
                      'courrier' => $courrier
                  ]);
              } elseif($courrier==''){
                return response()->json([
                    'statut' => true,
                    'message' => 'aucun courrier'
                ]);
              }
              else {
                  return response()->json([
                      'statut' =>false,             
                      'message' => 'dossier vide'], 401);
              }           
       }
    

       public function demande_Abscence_conge(Request $request)
       {
         
           $validatedData = $request->validate([
               'date_du_courrier' => 'required',
               'type_de_courrier' => 'required',
               'date_debut' => 'required',
               'date_fin' => 'required',
               'motif' => 'required',
               'id_employe' => 'required',
   
           ]);
   
           
           $courrier = new Courrier();
           $courrier->date_du_courrier = $validatedData['date_du_courrier'];
           $courrier->type_de_courrier = $validatedData['type_de_courrier'];
           $courrier->date_debut = $validatedData['date_debut'];
           $courrier->date_fin = $validatedData['date_fin'];
           $courrier->motif = $validatedData['motif'];
           $courrier->id_employe = $validatedData['id_employe'];
   
          
   
           $courrier->save();
           if ($courrier) {
   
               return response()->json([
                   'statut' => true,
                   'body' => $courrier
               ]);
           } else {
               return response()->json([
                   'statut' => false,
                   'message' => 'envois impossible'
               ]);
           }
   
   
   
           
       }
   
}
