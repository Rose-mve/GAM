<?php

namespace App\Http\Controllers;
use App\Models\Fiche_de_paie;
use App\Models\Employee;
use App\Models\User;
use PDF;

use Illuminate\Support\Facades\Storage;

use App\Notifications\FicheDePaieCreer;
use Illuminate\Http\Request;

class fiche_de_paieController extends Controller
{
    public function creerFiche_de_paie(Request $request)
    {
       
        $validatedData = $request->validate([
            'mois' => 'required|string',
            'periode_debut'=>'required|date', 
            'periode_fin'=>'required|date', 
            'primes' => 'nullable|numeric',
            'id_employe' => 'required|exists:employees,id',
            'statut' => 'nullable|string',
            'salaire_brut'=>'nullable|numeric',
            'indemnites' =>'nullable|numeric',
            'mode_de_paiement'=>'nullable|string',
            'date_de_paiement'=>'nullable|date',            
            'precompte_cnss'=>'nullable|numeric',
            'precompte_cnamgs'=>'nullable|numeric',
            'salaire_net' =>'nullable|numeric',
        ]);
    
        
        $employe = Employee::findOrFail($validatedData['id_employe']);
        $salaire = $employe->salaire; 

    
        
        $salaire_brut = $salaire + $validatedData['primes'];
    
        
        $precompte_cnss = $salaire_brut * 0.025; 
        $precompte_cnamgs = $salaire_brut * 0.02; 
        
    
        
        $salaire_net = $salaire_brut - $precompte_cnss - $precompte_cnamgs;
    
        
        $Fiche_de_paie = new Fiche_de_paie();
      
        $Fiche_de_paie->mois = $validatedData['mois'];
        $Fiche_de_paie->periode_debut = $validatedData['periode_debut'];
        $Fiche_de_paie->periode_fin = $validatedData['periode_fin'];
        $Fiche_de_paie->indemnites = $validatedData['indemnites'];
        $Fiche_de_paie->salaire_brut = $salaire_brut;
        $Fiche_de_paie->primes = $validatedData['primes'];
        $Fiche_de_paie->precompte_cnss = $precompte_cnss; 
        $Fiche_de_paie->precompte_cnamgs = $precompte_cnamgs; 
        $Fiche_de_paie->salaire_net = $salaire_net;
        $Fiche_de_paie->id_employe = $validatedData['id_employe'];
        $Fiche_de_paie->statut = $validatedData['statut'] ?? null;
        $Fiche_de_paie->mode_de_paiement = $validatedData['mode_de_paiement'] ?? null;
        $Fiche_de_paie->date_de_paiement = $validatedData['date_de_paiement'] ?? null;
    
        $Fiche_de_paie->save();
    
    
        $user = User::find($validatedData['id_employe']); 
        if ($user) {
            $user->notify(new FicheDePaieCreer($Fiche_de_paie));
        }
    
        //return redirect()->route('listeFiche_de_paie')->with('success', 'Fiche ajoutée avec succès.');
        return view('remuneration.fiche_de_paie', [
            'employe' => $employe,
            'Fiche_de_paie' => $Fiche_de_paie,
        ])->with('success', 'Fiche ajoutée avec succès.');
    }
    public function listeFiche_de_paie()
    {
       
        $Fiche_de_paies = Fiche_de_paie::where(function($query) {
            $query->where('statut', '!=', '1')
                  ->orWhereNull('statut');
        })->get();
            return view('remuneration.liste', compact('Fiche_de_paies'));
       /* return response()->json([
            'statut' => true,
            'body' => $Fiche_de_paies
        ]);*/

    }

    public function edite_Fiche_de_paie($id)
    {
        $Fiche_de_paie = Fiche_de_paie::find($id);
        return view('remuneration.modifier', compact('Fiche_de_paie'));

        /*return response()->json([
            'statut' => true,
            'body' => $Fiche_de_paie
        ]);*/
    }

    public function modifier_Fiche_de_paie(Request $request, $id)
    {
        $Fiche_de_paie = Fiche_de_paie::find($id);
        $validatedData = $request->validate([
            'date_fiche_de_paie'=>'required',
            'salaire_brut'=>'required',
            'primes'=>'required',
            'impots'=>'required',
            'securite_sociale'=>'required',
            'autre_retenus'=>'required',
            'salaire_net'=>'required',
            'id_employe'=>'required',
            'statut'=> 'nullable|string',

        ]);

        $Fiche_de_paie->fill($validatedData);

        $Fiche_de_paie->save();
       /* if ($Fiche_de_paie) {
            return response()->json([
                'statut' => true,
                'body' => $Fiche_de_paie,
                'message' => 'Fiche de paie  modifié'
            ]);
        } else {
            return response()->json([
                'statut' => false,
                'message' => 'modification non effectué'
            ], 404);
        }*/
        if ($Fiche_de_paie) {
            return redirect()->route('listeFiche_de_paie')->with('success', 'fiche modifié.');   
        } else {
            return redirect()->route('listeFiche_de_paie')->with('echoue', 'modification non effectué.');
        }



    }


    public function recherche_Fiche_de_paie($matricule)
    {
        $employe = Employee::where('matricule', $matricule)->first();
    
        if ($employe) {
            
            $ficheDePaie = Fiche_de_paie::where('id_employe', $employe->id)->first();
    
            if ($ficheDePaie) {
                return response()->json([
                    'statut' => true,
                    'body' => $ficheDePaie
                ]);
            } else {
                return response()->json([
                    'statut' => true,
                    'message' => 'Fiche de paie non trouvée'
                ], 404);
            }
        } else {
            return response()->json([
                'statut' => false,
                'message' => 'Employé non trouvé'
            ], 404);
        }
    }

    public function archiver_Fiche_de_paie($id)
    {
        $Fiche_de_paie = Fiche_de_paie::find($id);

        $Fiche_de_paie->statut = 1;
        $Fiche_de_paie->save();

        if ($Fiche_de_paie) {
            return redirect()->route('listeFiche_de_paie')->with('success', 'Fiche de paie archivé.');   
        } else {
            return redirect()->route('listeFiche_de_paie')->with('echoue', 'Archivage  non effectué.');
        }


       /* if ($Fiche_de_paie) {
            return response()->json([
                'statut' => true,
                'message' => 'Fiche de paie archivé'
            ]);
        } else {
            return response()->json([
                'statut' => false,
                'message' => 'Archivage  non effectué'
            ], 404);
        }*/


    }

    public function listeFiche_de_paieArchive()
    {
        $Fiche_de_paies = Fiche_de_paie::where('statut', '=', 1)->get();


        if ($Fiche_de_paies) {
            return response()->json([
                'statut' => true,
                'body' => $Fiche_de_paies
            ]);
        } else {
            return response()->json([
                'statut' => false,
                'message' => 'Aucun employé archivé'
            ], 404);
        }

    }
   
    public function formulaireAjoutfichedepaie($id)
{
    $employe = Employee::find($id);
    return view('remuneration.ajout', compact('employe'));
}
   
public function affiche($id)
    {
        $Fiche_de_paie = Fiche_de_paie::findOrFail($id);
        
      
        $employe = $Fiche_de_paie->employe; 
        return view('remuneration.fiche_de_paie', [
            'employe' => $employe,
            'Fiche_de_paie' => $Fiche_de_paie,
        ])->with('success', 'Fiche ajoutée avec succès.');
     }



    

     public function exporterpdf($id)
     {
         $Fiche_de_paie = Fiche_de_paie::findOrFail($id);
         $employe = $Fiche_de_paie->employe;
         $html = view('remuneration.fiche_de_paie2', compact('employe', 'Fiche_de_paie'))->render();
         $pdf = PDF::loadHTML($html);
         return $pdf->download('fiche_de_paie_' . $employe->nom . '.pdf');
     }
 
 







}

