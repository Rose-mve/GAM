<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Fiche_de_paie extends Model
{
    use HasFactory;
            protected $fillable = [
      
                'periode_debut',
                'periode_fin',
                'mois',
                'salaire_brut',
                'primes',
                'precompte_cnss',
                'precompte_cnamgs',
                'indemnites',
                'salaire_net',
                'statut',
                'mode_de_paiement',
                'date_de_paiement',
                'id_employe',
         ];
         public function employe()
         {
            return $this->belongsTo(Employee::class, 'id_employe');
         }
}
