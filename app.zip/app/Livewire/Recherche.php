<?php

namespace App\Livewire;

use App\Models\Employee;
use Livewire\Component;

class Recherche extends Component
{
    public ?string $search; 

    public function render()
    {
        
        if (empty($this->search)) {
            $employes = []; 
        } else {
            $employes = Employee::where('matricule', 'like', '%' . $this->search . '%')->get();
        }
       
        
       

        return view('livewire.recherche', [
            'employes' => $employes,
        ]);
        
    }
}
