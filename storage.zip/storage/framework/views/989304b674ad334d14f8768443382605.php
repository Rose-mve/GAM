

<?php $__env->startSection('title', 'Ajouter un Employé'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xxl">
        <div class="card mb-4">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h2>Créer un Employé</h2>
            </div>
            <div class="card-body">
                <form id="employeForm" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="nom">Nom</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nom" name="nom" required />
                            <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="prenom">Prénom</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="prenom" name="prenom" required />
                            <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                         </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label">Genre</label>
                        <div class="col-sm-10">
                            <div class="form-check">
                                <input name="genre" class="form-check-input" type="radio" value="masculin" id="masculin" checked />
                                <label class="form-check-label" for="masculin">Masculin</label>
                            </div>
                            <div class="form-check">
                                <input name="genre" class="form-check-input" type="radio" value="feminin" id="feminin" />
                                <label class="form-check-label" for="feminin">Féminin</label>
                            </div>
                            <?php $__errorArgs = ['genre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label" for="profession">Profession</label>
                        <div class="col-sm-10">
                            <select id="profession" class="form-select" name="profession" required>
                                <option value="chef de service">Chef de service</option>
                                <option value="agent">Agent</option>
                                <option value="stagiaire">Stagiaire</option>
                            </select>
                            <?php $__errorArgs = ['profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label" for="departement">Département</label>
                        <div class="col-sm-10">
                            <select id="departement" class="form-select" name="departement" required>
                                <option value="produit_digitaux">Produit Digitaux</option>
                                <option value="sigma">Sigma</option>
                                <option value="it">IT</option>
                                <option value="international & marketing">International & Marketing</option>
                            </select>
                            <?php $__errorArgs = ['departement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label" for="service">Service</label>
                        <div class="col-sm-10">
                            <select id="service" class="form-select" name="service" required>
                                <option value="mission zone B">Mission zone B</option>
                                <option value="assistance rapproche">Assistance rapproché</option>
                                <option value="mission zone A">Mission zone A</option>
                                <option value="design et production">Design et production</option>
                                <option value="recherche et developement">Recherche et développement</option>
                                <option value="international">International</option>
                                <option value="marketing">Marketing</option>
                            </select>
                            <?php $__errorArgs = ['service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="numcnss">N°CNSS</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="numcnss" name="numcnss" />
                            <?php $__errorArgs = ['numcnss'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="tel">Téléphone</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="tel" name="tel" required />
                            <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="email">Email</label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control" id="email" name="email" required />
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12 mb-3">
                        <h5>Photo</h5>
                        <input type="file" id="photo" name="photo" required />
                        <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3 row">
                        <label for="date_debut_contrat" class="col-md-2 col-form-label">Date de Début du contrat</label>
                        <div class="col-md-10">
                            <input class="form-control" type="date" id="date_debut_contrat" name="date_debut_contrat" required />
                            <?php $__errorArgs = ['date_debut_contrat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="date_fin_contrat" class="col-md-2 col-form-label">Date de Fin du contrat</label>
                        <div class="col-md-10">
                            <input class="form-control" type="date" id="date_fin_contrat" name="date_fin_contrat" required />
                            <?php $__errorArgs = ['date_fin_contrat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label" for="type_contrat">Type de Contrat</label>
                        <div class="col-sm-10">
                            <select id="type_contrat" class="form-select" name="type_contrat" required>
                                <option value="CDD">CDD</option>
                                <option value="CDI">CDI</option>
                                <option value="Stage_ecole">Stage École</option>
                                <option value="Stage_travail">Stage Travail</option>
                            </select>
                            <?php $__errorArgs = ['type_contrat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="salaire" class="col-md-2 col-form-label">Salaire</label>
                        <div class="col-md-10">
                            <input class="form-control" type="number" id="salaire" name="salaire" required />
                            <?php $__errorArgs = ['salaire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12 mb-3">
                        <h5>Fichier du Contrat</h5>
                        <input type="file" id="contrat_pdf" name="contrat_pdf" />
                        <?php $__errorArgs = ['contrat_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="row justify-content-end">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">Ajouter</button>
                        </div>
                    </div>
                </form>
                <div id="success-message" class="alert alert-success d-none"></div>
                <div id="error-message" class="alert alert-danger d-none"></div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    $(document).ready(function() {
        $('#employeForm').on('submit', function(e) {
            e.preventDefault(); // Empêche le rechargement de la page

            $.ajax({
                url: '<?php echo e(route('creerEmploye')); ?>', // Utilisez la route nommée
                method: 'POST',
                data: new FormData(this), // Envoie les données du formulaire
                contentType: false,
                processData: false,
                success: function(response) {
                    $('#success-message').removeClass('d-none').text(response.message);
                    $('#employeForm')[0].reset(); // Réinitialise le formulaire
                    $('#error-message').addClass('d-none'); // Cache le message d'erreur
                    $('.error').text(''); // Réinitialise les messages d'erreur

                    // Redirection vers la route
                    window.location.href = response.redirect;
                },
                error: function(xhr) {
                    // Gérer les erreurs de validation
                    $('#error-message').removeClass('d-none').text('Une erreur s\'est produite.');
                    $('.error').text(''); // Réinitialise les messages d'erreur
                    $.each(xhr.responseJSON.errors, function(key, value) {
                        $('#error-' + key).text(value[0]);
                    });
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\api_gestion_rh\resources\views/employes/ajout.blade.php ENDPATH**/ ?>