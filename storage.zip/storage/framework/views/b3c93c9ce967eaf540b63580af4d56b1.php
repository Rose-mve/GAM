<img src="<?php echo e(asset('assets/images/logoGam.png')); ?>" >
<?php /**PATH C:\xampp\htdocs\xampp\api_gestion_rh\resources\views/components/application-logo.blade.php ENDPATH**/ ?>