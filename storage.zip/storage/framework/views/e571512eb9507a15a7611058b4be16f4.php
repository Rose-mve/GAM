

<?php $__env->startSection('title', 'Liste des Rémunérations'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="row mb-3">
        <div class="col-9">
            <h1>Liste des Rémunérations</h1>
        </div>
        <div class="col-3 text-end">
            <button class="btn btn-primary">
                <a href="<?php echo e(url('/formulaireAjout')); ?>" style="text-decoration: none; color: white;">Ajouter une
                    Rémunération</a>
            </button>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <table class="table table-striped table-bordered" id="dt">
                <thead class="table-light">
                    <tr>
                        <th>Date</th>
                        <th>Salaire Brut</th>
                        <th>Primes</th>
                        <th>Impôts</th>
                        <th>Sécurité Sociale</th>
                        <th>Salaire Net</th>
                        <th>Modifier</th>
                        <th>Archiver</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $Fiche_de_paies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Fiche_de_paie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($Fiche_de_paie->date_fiche_de_paie); ?></td>
                            <td><?php echo e($Fiche_de_paie->salaire_brut); ?> </td>
                            <td><?php echo e($Fiche_de_paie->primes); ?> </td>
                            <td><?php echo e($Fiche_de_paie->impots); ?> </td>
                            <td><?php echo e($Fiche_de_paie->securite_sociale); ?> </td>
                            <td><?php echo e($Fiche_de_paie->salaire_net); ?> </td>
                            <td>
                                <button class="btn btn-success">
                                    <a href="<?php echo e(url('/Fiche_de_paie/' . $Fiche_de_paie->id . '/editer')); ?>"
                                        style="text-decoration: none; color: white;">Modifier</a>
                                </button>
                            </td>
                            <td>
                                <button class="btn btn-danger">
                                    <a href="<?php echo e(route('archiver_Fiche_de_paie', ['id' => $Fiche_de_paie->id])); ?>"
                                        style="text-decoration: none; color: white;">Archiver</a>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\api_gestion_rh\resources\views/remuneration/liste.blade.php ENDPATH**/ ?>