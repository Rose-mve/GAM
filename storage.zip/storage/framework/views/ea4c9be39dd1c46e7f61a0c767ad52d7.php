

<?php $__env->startSection('title', 'Liste des courries$courries'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="row mb-3">
        <div class="col-9">
            <h1>Liste des courriers</h1>
        </div>
        <div class="col-3 text-end">
            <button class="btn btn-primary">
                <a href="<?php echo e(url('/formulaireAjoutSanction')); ?>" style="text-decoration: none; color: white;">Ajouter une courrier</a>
            </button>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <table class="table table-striped table-bordered" id="dt">
                <thead class="table-light">
                    <tr>
                        
                        <th>Date du Courrier</th>
                        <th>Type de courrier</th>
                        <th>Motif</th>
                        <th>Date de Début</th>
                        <th>Date de Fin</th>
                       
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $courriers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courrier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           
                            <td><?php echo e($courrier->date_du_courrier); ?></td>
                            <td><?php echo e($courrier->type_de_courrier); ?></td>
                            <td><?php echo e($courrier->motif); ?></td>
                            <td><?php echo e($courrier->date_debut); ?></td>
                            <td><?php echo e($courrier->date_fin); ?></td>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\api_gestion_rh\resources\views/courrier/liste.blade.php ENDPATH**/ ?>