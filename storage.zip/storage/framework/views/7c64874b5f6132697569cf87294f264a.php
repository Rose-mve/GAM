

<?php $__env->startSection('title', 'Liste des Employés'); ?>

<?php $__env->startSection('content'); ?>



<div class="container-xxl flex-grow-1 container-p-y">
    <div class="col-12">
        <div class="card mb-4">
            <div class="user-profile-header-banner">
                <img src="../../assets/img/pages/profile-banner.png" alt="Banner image" class="rounded-top" />
            </div>
            <div class="user-profile-header d-flex flex-column flex-sm-row text-sm-start text-center mb-4">
                <div class="flex-shrink-0 mt-n2 mx-sm-0 mx-auto">
                    <!-- Ajoutez ici une image ou une icône de profil si nécessaire -->
                </div>
                <div class="flex-grow-1 mt-3 mt-sm-5">
                    <div
                        class="d-flex align-items-md-end align-items-sm-start align-items-center justify-content-md-between justify-content-start mx-4 flex-md-row flex-column gap-4">
                        <div class="user-profile-info">
                            <!-- Informations de l'utilisateur -->
                        </div>
                        <a class="btn btn-primary" href="<?php echo e(url('/formulaireAjoutE')); ?>" style="text-decoration: none;">
                            <i class="bx bx-user-plus"></i> Ajouter un Employé
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <h4 class="py-3 breadcrumb-wrapper mb-4">
            <span class="text-muted fw-light">Recherche</span>
        </h4>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('recherche');

$__html = app('livewire')->mount($__name, $__params, 'lw-3675758476-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <h4 class="py-3 breadcrumb-wrapper mb-4">
            <span class="text-muted fw-light">liste des employés</span>
        </h4>


        <div id="dt">

            <div class="row g-4">
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-4 col-lg-6 col-md-6">
                        <div class="card">
                            <div class="card-body text-center">


                                <div class="mx-auto mb-3">
                                    <img src="<?php echo e(asset('storage/' . $employe->photo)); ?>" alt="Avatar Image"
                                        class="rounded-circle w-px-100" />
                                </div>

                                <h5 class="mb-1 card-title"><?php echo e($employe->nom); ?></h5>
                                <span><?php echo e($employe->profession); ?></span>

                                <div class="d-flex align-items-center justify-content-center my-3 gap-2">
                                    <a href="javascript:;" class="me-1"><span
                                            class="badge bg-label-secondary"><?php echo e($employe->departement); ?></span></a>
                                    <a href="javascript:;"><span
                                            class="badge bg-label-warning"><?php echo e($employe->service); ?></span></a>
                                </div>

                                <div class="d-flex align-items-center justify-content-around my-4 py-2">
                                    <div>
                                        <h4 class="mb-1"><?php echo e($employe->contrats_count); ?></h4>
                                        <span>contrats</span>

                                    </div>
                                    <div>
                                        <h4 class="mb-1"><?php echo e($employe->fiche_de_paies_count); ?></h4>
                                        <span>remuneration</span>
                                    </div>
                                    <div>
                                        <h4 class="mb-1"><?php echo e($employe->courriers_count); ?></h4>
                                        <span>courrier</span>
                                    </div>
                                </div>

                                <div class="d-flex align-items-center justify-content-center">
                                    <a href="<?php echo e(url('/formulaireAjoutSanction/' . $employe->id . '/courrier')); ?>"
                                        class="btn btn-label-secondary btn-icon me-2">
                                        <i class="bx bx-envelope"></i>
                                    </a>
                                    <a href="<?php echo e(url('/employe/' . $employe->id . '/archiver')); ?>"
                                        class="btn btn-label-secondary btn-icon me-2">
                                        <i class="bx bx-archive"></i>
                                    </a>
                                    <a href="<?php echo e(url('/formulaireAjout/' . $employe->id . '/remunerer')); ?>"
                                        class="btn btn-label-secondary btn-icon me-2">
                                        <i class="bx bx-calculator"></i>
                                    </a>
                                    <a href="<?php echo e(url('/employe/' . $employe->id . '/editer')); ?>"
                                        class="btn btn-label-secondary btn-icon me-2">
                                        <i class="bx bxs-edit"></i>
                                    </a>
                                    <a href="<?php echo e(url('/consulter/' . $employe->id . '/consulter')); ?>"
                                        class="btn btn-label-secondary btn-icon">
                                        <i class="bx bx-news"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\api_gestion_rh\resources\views/employes/liste.blade.php ENDPATH**/ ?>