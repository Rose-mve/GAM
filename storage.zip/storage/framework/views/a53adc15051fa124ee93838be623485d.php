

<?php $__env->startSection('title', 'modifier employe'); ?>

<?php $__env->startSection('content'); ?>



<div class="row">
    <!-- Basic Layout -->
    <div class="col-xxl">
        <div class="card mb-4">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h2>Modifier un Employé</h2>

            </div>
            <div class="card-body">
                <form action="<?php echo e(url('/employe/' . $employe->id . '/modifier_employe')); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="nom">Nom</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nom" value="<?php echo e(old('nom', $employe->nom)); ?>" name="nom"
                               disabled/>
                            <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="prenom">prenom</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="prenom" placeholder="entrez le prénom"
                                name="prenom" disabled value="<?php echo e(old('prenom', $employe->prenom)); ?>" />
                            <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label">genre</label>
                        <div class="col-sm-9">
                            <div class="form-check mb-2">
                                <input name="genre" class="form-check-input" type="radio" value="masculin" id="masculin"
                                    checked=""   value="<?php echo e(old('genre', $employe->genre)); ?>" disabled/>
                                <label class="form-check-label" for="collapsible-addressType-home">
                                    masculin
                                </label>
                                <?php $__errorArgs = ['genre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-check">
                                <input name="genre" class="form-check-input" type="radio" value="feminin"
                                    id="feminin" disabled /> <label class="form-check-label" for="genre" >

                                    feminin
                                </label>
                                <?php $__errorArgs = ['genre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label" for="profession">proféssion</label>
                        <div class="col-sm-10">
                            <select id="profession" class="form-select" name="profession" name="profession" value="<?php echo e(old('profession', $employe->profession)); ?>" disabled>
                                <option value="chef de service">Chef de service</option>
                                <option value="Agent">Agent</option>
                                <option value="stagiaire">Stagiaire</option>
                            </select>
                            <?php $__errorArgs = ['profession'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label" for="departement">Département</label>
                        <div class="col-sm-10">
                            <select id="departement" class="form-select" name="departement" name="profession" value="<?php echo e(old('profession', $employe->departement)); ?>" disabled>
                                <option value="produit_digitaux">Produit Digitaux</option>
                                <option value="sigma">Sigma</option>
                                <option value="it">It</option>
                                <option value="international & marketing">International & marketing</option>
                            </select>
                            <?php $__errorArgs = ['departement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label" for="service">Service</label>
                        <div class="col-sm-10">
                            <select id="service" class="form-select" name="service" value="<?php echo e(old('profession', $employe->service)); ?>" disabled>
                                <option value="mission zone B">Mission zone B</option>
                                <option value="assistance rapproche">assistance rapproché</option>
                                <option value="mission zone A">Mission zone A</option>
                                <option value=" design et production">design et production</option>
                                <option value=" recherche et developement"> recherche et developement</option>
                                <option value=" international"> international</option>
                                <option value=" marketing"> marketing</option>
                            </select>
                            <?php $__errorArgs = ['service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="numcnss">N°CNSS</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="numcnss" name="numcnss"  value="<?php echo e(old('profession', $employe->numcnss)); ?>"
                                placeholder="numcnss."  disabled/>
                            <?php $__errorArgs = ['numcnss'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="tel">tel</label>
                        <div class="col-sm-10">
                            <input type="text" id="tel" class="form-control phone-mask" placeholder="+241"
                                aria-label="+241" aria-describedby="basic-default-phone" name="tel"  value="<?php echo e(old('profession', $employe->tel)); ?>"  disabled/>
                            <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="email">Email</label>
                        <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                                <input type="email" id="email" class="form-control" placeholder="email" value="<?php echo e(old('email', $employe->email)); ?>"
                                    aria-label="email" aria-describedby="basic-default-email2" name="email" disabled />
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card mb-4">
                            <h5 class="card-header">Photo</h5>
                            <div class="card-body">
                                <div class="dz-message needsclick">
                                    clicker ici pour telecharger l'image
                                </div>
                                <div class="fallback">
                                    <input type="file" id="photo" name="photo" value="<?php echo e(old('photo', $employe->photo)); ?>" />
                                    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="date_debut_contrat" class="col-md-2 col-form-label">Date de Debut du contrat</label>
                        <div class="col-md-10">
                            <input class="form-control" type="date" id="date_debut_contrat" name="date_debut_contrat"
                                required />
                            <?php $__errorArgs = ['date_debut_contrat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="date_embauche" class="col-md-2 col-form-label">Date d'embauche</label>
                        <div class="col-md-10">
                            <input class="form-control" type="date" id="date_embauche" name="date_embauche"
                                required />
                            <?php $__errorArgs = ['date_embauche'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="date_fin_contrat" class="col-md-2 col-form-label">Date de fin du contrat</label>
                        <div class="col-md-10">
                            <input class="form-control" type="date" id="date_fin_contrat" name="date_fin_contrat"
                                required />
                            <?php $__errorArgs = ['date_fin_contrat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label" for="type_contrat">Type de Contrat </label>
                        <div class="col-sm-10">
                            <select id="type_contrat" class="form-select" name="type_contrat">
                                <option value="CDD">CDD</option>
                                <option value="CDI">CDI</option>
                                <option value="Stage_ecole">Stage Ecole</option>
                                <option value="Stage_travail">Stage Travail</option>
                            </select>
                            <?php $__errorArgs = ['type_contrat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="mb-3 row">
                        <label for="salaire" class="col-md-2 col-form-label">Salaire</label>
                        <div class="col-md-10">
                            <input class="form-control" type="number" id="salaire" placeholder="1000000"
                                name="salaire" />
                            <?php $__errorArgs = ['salaire'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card mb-4">
                            <h5 class="card-header">fichier du contrat</h5>
                            <div class="card-body">
                                <div class="dz-message needsclick">
                                    clicker ici pour telecharger le fichier du contrat
                                </div>
                                <div class="fallback">
                                    <input type="file" id="contrat_pdf" name="contrat_pdf" />
                                    <?php $__errorArgs = ['contrat_pdf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-end">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">Modifier</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\api_gestion_rh\resources\views/employes/modifier.blade.php ENDPATH**/ ?>