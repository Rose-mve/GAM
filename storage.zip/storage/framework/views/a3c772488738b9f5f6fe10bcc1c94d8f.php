

<?php $__env->startSection('title', 'Fiche de Paie'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <div class="row">
        <div class="col-6 text-dark py-2">
            <div class="row">
                <div class="col-3">
                    <img src="<?php echo e(asset('images/logoGam.png')); ?>" alt="" style="width:100px; height: 100px;">
                </div>
                <div class="col-9">
                    <h1>GAM Gabon</h1>
                    <span>Création de système intelligent</span>
                </div>
            </div>
        </div>
        <div class="col-6 text-dark py-2 ">
            <div class="d-flex justify-content-end"> 
                
              
              <a href="<?php echo e(url('fiche-de-paie/' . $Fiche_de_paie->id . '/exporter-pdf')); ?>" style="color: white; text-decoration: none; background-color: #007bff; padding: 10px 15px; border-radius: 5px;">
                    Télécharger <i class="bx bx-download" style="color:withe; width=100px"></i> 
                </a>
                
            </div>
        </div>
    </div>
    <div class="row">
        <div class="row">
            <div class="col-4 text-dark text-center py-2 border border-dark">
                <h5>Employeur</h5>
                <div class="text-align-left">
                    <span>GAM GABON</span><br>
                    <span>Terasse de l'Estuaire / Libreville</span><br>
                    <span>BP: 2263</span><br>
                </div>
            </div>
            <div class="col-4 text-dark text-center py-2 border border-dark">
                <h5>Employé</h5>
                <div class="text-align-left">
                    <span>Matricule: <?php echo e($employe->matricule); ?></span><br>
                    <span>N°CNSS: <?php echo e($employe->numcnss); ?></span><br>
                    <span>Nom: <?php echo e($employe->nom); ?></span><br>
                    <span>Prenom: <?php echo e($employe->prenom); ?></span><br>
                </div>
            </div>
            <div class="col-4 text-dark text-center py-2 border border-dark">
                <h5>Période</h5>
                <div class="text-align-left">
                    <span>Mois: <?php echo e($Fiche_de_paie->mois); ?></span><br>
                    <span>Du: <?php echo e($Fiche_de_paie->periode_debut); ?></span><br>
                    <span>Au: <?php echo e($Fiche_de_paie->periode_fin); ?></span><br>
                    <span>jour:30/30</span><br>
                </div>
            </div>
        </div>
        <div class="row ">
            <div class="col-4 text-dark text-center py-2 border border-dark">
                <h5>Salaires</h5>
                <div class="text-align-left">
                    <span>salaire de base</span><br>
                    <span>Prime d'objectifs </span><br>
                    <span>-</span><br>
                </div>
            </div>
            <div class="col-4 text-dark text-center py-2 border border-dark">
                <h4>Base</h4>
                <div class="text-align-left">
                    <span><?php echo e($employe->salaire); ?></span><br>
                    <span><?php echo e($Fiche_de_paie->primes); ?></span><br>
                    <span>-</span><br>
                </div>
            </div>
            <div class="col-4 text-dark text-center py-2 border border-dark">
                <div class="text-align-left"></div>
            </div>
        </div>
        <div class="row">
            <div class="col-6 text-dark text-center py-2 border border-dark">
                <div class="text-align-left">
                    <h4>SALAIRE BRUT</h4>
                </div>
            </div>
            <div class="col-6 text-dark text-center py-2 border border-dark">
                <div class="text-right">
                    <?php echo e($Fiche_de_paie->salaire_brut); ?>

                </div>
            </div>
        </div>
        <div class="row ">
            <div class="col-4 text-dark text-center py-2 border border-dark">
                <h5>COTISATION</h5>
                <div class="text-align-left">
                    <span>precompte CNSS</span><br>
                    <span>Precompte CNAMGS </span><br>
                    <span>-</span><br>
                </div>
            </div>
            <div class="col-4 text-dark text-center py-2 border border-dark">
                <h4>Base</h4>
                <div class="text-align-left">
                    <span>2,5%</span><br>
                    <span>2%</span><br>
                    <span>-</span><br>
                </div>
            </div>
            <div class="col-4 text-dark text-center py-2 border border-dark">
                <h4>Base</h4>
                <div class="text-align-left">
                    <span><?php echo e($Fiche_de_paie->precompte_cnss); ?></span><br>
                    <span><?php echo e($Fiche_de_paie->precompte_cnamgs); ?></span><br>
                    <span>-</span><br>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-6 text-dark text-center py-2 border border-dark">
                <div class="text-align-left">
                    <h4>TOTAL COTISATION</h4>
                </div>
            </div>
            <div class="col-6 text-dark text-center py-2 border border-dark">
                <div class="text-right">
                    <?php echo e($Fiche_de_paie->precompte_cnss + $Fiche_de_paie->precompte_cnamgs); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-4 text-dark text-center py-2 border border-dark">
                <div class="text-align-left">
                    <h4>Indemnités</h4>
                </div>
            </div>
            <div class="col-4 text-dark text-center py-2 border border-dark">
                <div class="text-right">
                    <span>base</span>
                </div>
            </div>
            <div class="col-4 text-dark text-center py-2 border border-dark">
                <div class="text-right">
                    <span><?php echo e($Fiche_de_paie->indemnites); ?></span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-6 text-dark text-center py-2 border border-dark">
                <div class="text-align-left">
                    <h4>TOTAL INDEMNITES</h4>
                </div>
            </div>
            <div class="col-6 text-dark text-center py-2 border border-dark">
                <div class="text-right">
                    <?php echo e($Fiche_de_paie->indemnites); ?>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-6 text-dark text-center py-2 ">
                <div class="text-align-left"></div>
            </div>
            <div class="col-6 text-dark text-center py-2 border border-dark">
                <div class="text-right">
                    <span>Net à payer: <?php echo e($Fiche_de_paie->salaire_net); ?></span><br>
                    <span>Mode de paiement: <?php echo e($Fiche_de_paie->mode_de_paiement); ?></span><br>
                    <span>Date de paiement: <?php echo e($Fiche_de_paie->date_de_paiement); ?></span>
                </div>
            </div>
        </div>
        <div class="row">
            <h6>Emargement</h6>
            <div class="col-6 text-dark text-center py-2 border border-dark">
                <div class="text-align-left">
                    <span>Employeur</span><br>
                    <span></span><br>
                    <span></span><br>
                    <span></span><br>
                    <span></span>
                </div>
            </div>
            <div class="col-6 text-dark text-center py-2 border border-dark">
                <div class="text-right">
                    <span>Employé</span>
                    <span></span><br>
                    <span></span><br>
                    <span></span><br>
                    <span></span>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\api_gestion_rh\resources\views/remuneration/fiche_de_paie.blade.php ENDPATH**/ ?>