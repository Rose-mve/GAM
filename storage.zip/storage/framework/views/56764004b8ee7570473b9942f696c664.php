<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Télécharger</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            color: #343a40;
        }
        .container {
            margin: 20mm; /* Ajuste les marges pour le format A4 */
        }
        .header {
            text-align: center;
            margin-bottom: 10px;
        }
        .header img {
            width: 80px; /* Réduit la taille de l'image */
            height: auto;
            margin-bottom: 10px;
        }
        .section {
            display: flex;
            margin-bottom: 10px;
        }
        .box {
            flex: 3;
            text-align: center;
            padding: 10px;
            border: 1px solid #000;
        }
        h1, h4, h5 {
            margin: 5px 0; 
        }
        .footer {
            margin-top: 20px;
        }
        .emargement {
            display: flex;
            margin-bottom: 10px;
        }
        .emargement div {
            flex: 1;
            text-align: center;
            padding: 10px;
            border: 1px solid #000;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">
            <img src="<?php echo e(asset('images/logoGam.png')); ?>" alt="">
            <h1>GAM Gabon</h1>
            <span>Création de système intelligent</span>
        </div>

        <div class="section">
            <div class="box">
                <h5>Employeur</h5>
                <div style="text-align: left;">
                    <span>GAM GABON</span><br>
                    <span>Terasse de l'Estuaire / Libreville</span><br>
                    <span>BP: 2263</span><br>
                </div>
            </div>
            <div class="box">
                <h5>Employé</h5>
                <div style="text-align: left;">
                    <span>Matricule: <?php echo e($employe->matricule); ?></span><br>
                    <span>N°CNSS: <?php echo e($employe->numcnss); ?></span><br>
                    <span>Nom: <?php echo e($employe->nom); ?></span><br>
                    <span>Prenom: <?php echo e($employe->prenom); ?></span><br>
                </div>
            </div>
            <div class="box">
                <h5>Période</h5>
                <div style="text-align: left;">
                    <span>Mois: <?php echo e($Fiche_de_paie->mois); ?></span><br>
                    <span>Du: <?php echo e($Fiche_de_paie->periode_debut); ?></span><br>
                    <span>Au: <?php echo e($Fiche_de_paie->periode_fin); ?></span><br>
                    <span>Jour: 30/30</span><br>
                </div>
            </div>
        </div>

        <div class="section">
            <div class="box">
                <h5>Salaires</h5>
                <div style="text-align: left;">
                    <span>Salaire de base</span><br>
                    <span>Prime d'objectifs</span><br>
                </div>
            </div>
            <div class="box">
                <h4>Base</h4>
                <div style="text-align: left;">
                    <span><?php echo e($employe->salaire); ?></span><br>
                    <span><?php echo e($Fiche_de_paie->primes); ?></span><br>
                </div>
            </div>
            <div class="box"></div>
        </div>

        <div class="section">
            <div class="box">
                <h4>SALAIRE BRUT</h4>
                <div style="text-align: right;"><?php echo e($Fiche_de_paie->salaire_brut); ?></div>
            </div>
        </div>

        <div class="section">
            <div class="box">
                <h5>COTISATION</h5>
                <div style="text-align: left;">
                    <span>Prélèvement CNSS</span><br>
                    <span>Prélèvement CNAMGS</span><br>
                </div>
            </div>
            <div class="box">
                <h4>Base</h4>
                <div style="text-align: left;">
                    <span>2,5%</span><br>
                    <span>2%</span><br>
                </div>
            </div>
            <div class="box">
                <h4>Base</h4>
                <div style="text-align: left;">
                    <span><?php echo e($Fiche_de_paie->precompte_cnss); ?></span><br>
                    <span><?php echo e($Fiche_de_paie->precompte_cnamgs); ?></span><br>
                </div>
            </div>
        </div>

        <div class="section">
            <div class="box">
                <h4>TOTAL COTISATION</h4>
            </div>
            <div class="box">
                <div style="text-align: right;">
                    <?php echo e($Fiche_de_paie->precompte_cnss + $Fiche_de_paie->precompte_cnamgs); ?>

                </div>
            </div>
        </div>

        <div class="section">
            <div class="box">
                <h4>Indemnités</h4>
            </div>
            <div class="box">
                <span>Base</span>
            </div>
            <div class="box">
                <div style="text-align: right;">
                    <span><?php echo e($Fiche_de_paie->indemnites); ?></span>
                </div>
            </div>
        </div>

        <div class="section">
            <div class="box">
                <h4>TOTAL INDEMNITES</h4>
            </div>
            <div class="box">
                <div style="text-align: right;">
                    <?php echo e($Fiche_de_paie->indemnites); ?>

                </div>
            </div>
        </div>

        <div class="footer">
            <div class="section">
                <div class="box"></div>
                <div class="box">
                    <div style="text-align: right;">
                        <span>Net à payer: <?php echo e($Fiche_de_paie->salaire_net); ?></span><br>
                        <span>Mode de paiement: <?php echo e($Fiche_de_paie->mode_de_paiement); ?></span><br>
                        <span>Date de paiement: <?php echo e($Fiche_de_paie->date_de_paiement); ?></span>
                    </div>
                </div>
            </div>

            <div style="margin-top: 20px;">
                <h6>Emargement</h6>
                <div class="emargement">
                    <div>
                        <span>Employeur</span>
                    </div>
                    <div>
                        <span>Employé</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\xampp\api_gestion_rh\resources\views/remuneration/fiche_de_paie2.blade.php ENDPATH**/ ?>