

<?php $__env->startSection('title', 'Envoyer un courrier'); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <!-- Basic Layout -->
    <div class="col-xxl">
        <div class="card mb-4">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h4>Envoyer un Avenant à l'employé <?php echo e($employe->nom); ?></h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('/avenant')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <div class="mb-3 row">
                        <label for="date_du_courrier" class="col-md-2 col-form-label">Date du Courrier</label>
                        <div class="col-md-10">
                            <input class="form-control" type="date" id="date_du_courrier" name="date_du_courrier"
                                required />
                            <?php $__errorArgs = ['date_du_courrier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="mb-3 row" hidden>
                        <label class="col-sm-2 col-form-label" for="type_de_courrier" hidden>Type de Courrier</label>
                        <div class="col-sm-10" hidden>
                            <select id="type_de_courrier" class="form-select" name="type_de_courrier" required value="Avenant" hidden>
                                <option value="Sanction">Sanction</option>
                                <option value="Avenant">Avenant</option>
                                <option value="Demande d'explication">Demande d'explication</option>
                            </select>
                            <?php $__errorArgs = ['type_de_courrier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="motif">Note</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="motif" placeholder="motif"
                                name="motif"  />
                            <?php $__errorArgs = ['motif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="error"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <input type="hidden" name="id_employe" value="<?php echo e($employe->id); ?>">

                    <div class="row justify-content-end">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">envoyer</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\xampp\api_gestion_rh\resources\views/courrier/avenant.blade.php ENDPATH**/ ?>