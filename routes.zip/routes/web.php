<?php

use App\Http\Controllers\Auth\CustomAuthController;
use App\Http\Controllers\DashboardController;
use App\Models\User;
use App\Notifications\FicheDePaieCreer;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\employeController;
use App\Http\Controllers\WeatherController;
use App\Http\Controllers\statistiqueController;
use App\Http\Controllers\fiche_de_paieController;
use App\Http\Controllers\courrierController;


Route::get('/t', function () {
    return view('welcome');
});

//Route Employe
Route::post('/creeremploye', [employeController::class, 'creerEmploye'])->name('creerEmploye');
Route::get('/formulaireAjoutE', [employeController::class, 'formulaireAjoutemploye'])->name('formulaireAjoutemploye');
Route::get('/listeemploye', [employeController::class, 'listeEmployes'])->name('listeemploye');
Route::get('/employe/{id}/editer', [employeController::class, 'edite_employe'])->name('edite_employe');
Route::put('/employe/{employe}/modifier_employe', [employeController::class, 'modifier_employe'])->name('modifier_employe');
Route::get('/employe/{employe}/recherche', [employeController::class, 'recherche_employe'])->name('recherche_employe');
Route::get('/employe/{id}/archiver', [employeController::class, 'archiver_employe'])->name('archiver_employe');
Route::get('/listeemployeArchive', [employeController::class, 'listeEmployesArchive'])->name('listeEmployesArchive');
Route::get('/employe/{employe}/genererContrat', [employeController::class, 'genererContrat'])->name('genererContrat_employe');
Route::get('employes/{id}/exporter-pdf', [employeController::class, 'exporterpdf'])->name('exporterpdf');
Route::get('/consulter/{employe}/consulter', [employeController::class, 'consulterEmployer'])->name('consulterEmployer');
Route::get('/contrat/telecharger/{id}', [employeController::class, 'telecharger_contrat'])->name('telecharger_contrat');

Route::get('/statistiques', [statistiqueController::class, 'statistiques'])->name('statistiques');

//Route Fiches de paies
Route::post('/creerFiche_de_paie', [fiche_de_paieController::class, 'creerFiche_de_paie'])->name('creerFiche_de_paie');
Route::get('/listeFiche_de_paie', [fiche_de_paieController::class, 'listeFiche_de_paie'])->name('listeFiche_de_paie');
Route::get('/listeFiche_de_paieArchive', [fiche_de_paieController::class, 'listeFiche_de_paieArchive'])->name('listeFiche_de_paiesArchive');
Route::get('/Fiche_de_paie/{Fiche_de_paie}/editer', [fiche_de_paieController::class, 'edite_Fiche_de_paie'])->name('edite_Fiche_de_paie');
Route::get('/Fiche_de_paie/{matricule}/recherche', [fiche_de_paieController::class, 'recherche_Fiche_de_paie'])->name('recherche_Fiche_de_paie');
Route::put('/Fiche_de_paie/{Fiche_de_paie}/modifier', [fiche_de_paieController::class, 'modifier_Fiche_de_paie'])->name('modifier_Fiche_de_paie');
Route::put('/Fiche_de_paie/{id}/archiver', [fiche_de_paieController::class, 'archiver_Fiche_de_paie'])->name('archiver_Fiche_de_paie');
Route::get('/formulaireAjout/{employe}/remunerer', [fiche_de_paieController::class, 'formulaireAjoutfichedepaie'])->name('formulaireAjoutfichedepaie');
Route::get('/fiche-de-paie/{id}', [fiche_de_paieController::class, 'affiche'])->name('fiche_de_paie.affiche');
Route::get('fiche-de-paie/{id}/exporter-pdf', [fiche_de_paieController::class, 'exporterpdf'])->name('exporterfiche_de_paie_pdf');






//Route courriers
Route::post('/demande_Abscence_conge', [courrierController::class, 'demande_Abscence_conge'])->name('demande_Abscence_conge');
Route::get('/listeFiche_de_courrrier', [courrierController::class, 'listeFiche_de_courrrier'])->name('listeFiche_de_courrrier');


Route::post('/sanction', [courrierController::class, 'sanction'])->name('sanction');
Route::post('/avenant', [courrierController::class, 'sanction'])->name('avenant');
Route::put('/courrier/{courrier}/accepter', [courrierController::class, 'accepter_demande'])->name('accepter_demande');
Route::put('/courrier/{courrier}/refuser', [courrierController::class, 'refuser_demande'])->name('refuser_demande');
Route::get('/statistiques', [statistiqueController::class, 'statistiques'])->name('statistiques');
Route::get('/formulaireAjoutSanction/{employe}/courrier', [courrierController::class, 'formulaireAjoutSanction'])->name('formulaireAjoutSanction');
Route::get('/formAvenant/{employe}/courrier', [courrierController::class, 'formAvenant'])->name('formAvenant');
Route::get('/courrier/{id}/accepter', [courrierController::class, 'accepter_Courrier'])->name('accepter_Courrier');
Route::get('/courrier/{id}/refuser', [courrierController::class, 'refuser_Courrier'])->name('refuser_Courrier');






Route::get('/weather', [WeatherController::class, 'show']);


Route::get('/send-notification', function () {
    $user = User::find(1); 
    $user->notify(new FicheDePaieCreer('Test de notification !'));
    return 'Notification envoyée !';
});




Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
});
Route::post('/dashboard', [CustomAuthController::class, 'logout'])
    ->middleware('auth')
    ->name('logout');
