<?php

return [
    'paths' => ['api/*'], // Chemins qui nécessitent CORS
    'allowed_methods' => ['*'], // Méthodes HTTP autorisées
    'allowed_origins' => ['*'], // Origines autorisées
    'allowed_origins_patterns' => [],
    'allowed_headers' => ['*'], // En-têtes autorisés
    'exposed_headers' => [],
    'max_age' => 0,
    'supports_credentials' => false,
];