<x-app-layout>


    <div class="py-1">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="content-wrapper">
                    <nav class="layout-navbar navbar navbar-expand-xl align-items-center bg-navbar-theme"
                        id="layout-navbar">
                        <div class="container-fluid">
                            <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                                <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                                    <i class="bx bx-menu bx-sm"></i>
                                </a>
                            </div>


                            <div class="navbar-brand text-center me-auto">
                                <h2 class="text-dark mb-0">Gestion des employés</h2>
                            </div>

                            <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                                <ul class="navbar-nav flex-row align-items-center ms-auto">

                                    <!--deconnexion -->
                                    <form method="POST" action="{{ route('logout') }}">
                                        @csrf
                                        <button type="submit" class="dropdown-item">
                                            <i class="bx bx-log-out"></i>
                                            <span>Déconnexion</span>
                                        </button>
                                    </form>
                                    <!-- deconnexion-->

                                    <!-- Notification -->
                                    <li class="nav-item dropdown-notifications navbar-dropdown dropdown me-3 me-xl-2">
                                        <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);"
                                            data-bs-toggle="dropdown" data-bs-auto-close="outside"
                                            aria-expanded="false">
                                            <i class="bx bx-bell bx-sm"></i>
                                            <span class="badge bg-danger rounded-pill badge-notifications">.</span>
                                        </a>
                                    </li>
                                    <!--/ Notification -->

                                    <!-- utilisateur -->
                                    <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                        <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);"
                                            data-bs-toggle="dropdown">
                                            <div class="avatar avatar-online">
                                                <span class="fw-bold">{{ auth()->user()->name }}</span>
                                            </div>
                                        </a>
                                    </li>
                                    <!--/ utilisateur -->
                                </ul>
                            </div>
                        </div>
                    </nav>
                    <!-- Content -->

                    <div class="container-xxl flex-grow-1 container-p-y">

                        <div class="row">
                            <!-- statistiques-->
                            <div class="col-lg-6 col-md-6 mb-4">
                                <div class="card shadow-sm">
                                    <div class="card-header d-flex justify-content-between align-items-center "
                                        style="background-color:#c0c0c0">
                                        <h5 class="card-title mb-0">Statistiques</h5>
                                    </div>
                                    <div class="card-body pb-2">
                                        <div class="d-flex justify-content-around align-items-center flex-wrap mb-4">
                                            <div class="user-analytics text-center me-2">
                                                <i class="bx bx-user me-1 text-primary" style="font-size: 2rem;"></i>
                                                <span class="d-block font-weight-bold">Employés</span>
                                                <div class="d-flex align-items-center mt-2">
                                                    <div class="chart-report" data-color="success"
                                                        data-series="{{ $nombreEmployes }}"></div>
                                                    <h3 class="mb-0">{{ $nombreEmployes }}</h3>
                                                </div>
                                            </div>
                                            <div class="sessions-analytics text-center me-2">
                                                <i class="bx bx-mail-send me-1 text-warning"
                                                    style="font-size: 2rem;"></i>
                                                <span class="d-block font-weight-bold">Courriers</span>
                                                <div class="d-flex align-items-center mt-2">
                                                    <div class="chart-report" data-color="warning"
                                                        data-series="{{ $nombreCourriers }}"></div>
                                                    <h3 class="mb-0">{{ $nombreCourriers }}</h3>
                                                </div>
                                            </div>
                                            <div class="fiches-analytics text-center">
                                                <i class="bx bx-file me-1 text-danger" style="font-size: 2rem;"></i>
                                                <span class="d-block font-weight-bold">Fiches de Paie</span>
                                                <div class="d-flex align-items-center mt-2">
                                                    <div class="chart-report" data-color="danger"
                                                        data-series="{{ $nombrefiches_de_paie }}"></div>
                                                    <h3 class="mb-0">{{ $nombrefiches_de_paie }}</h3>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- statistiques-->

                            <!-- courriers -->
                            <div class="col-md-6 col-lg-6 col-xl-6 col-xxl-3 mb-4">
                                <div class="card shadow-sm">
                                    <div class="card-header text-white"
                                        style="background-color:#ff6700; text-align:center;">
                                        <h5 class="card-title mb-0 text-white ">Courriers</h5>
                                    </div>
                                    <div class="card-body">
                                        <ul class="list-unstyled">
                                            @foreach ($courriers as $courrier)
                                                <li class="d-flex align-items-start mb-4 pb-2 border-bottom">
                                                    <div class="d-flex flex-column w-100">
                                                        <div class="d-flex justify-content-between mb-9">
                                                            <div class="row-3">
                                                                <i
                                                                    class="bx bx-calendar-alt"></i>{{ date('d/m/Y', strtotime($courrier->date_du_courrier)) }}
                                                            </div>
                                                            <span class="fw-bold">Type de Courrier:</span>
                                                            <span
                                                                class="text-muted">{{ $courrier->type_de_courrier }}</span>
                                                        </div>
                                                        <div class="d-flex mb-2">
                                                            @if ($courrier->employes)
                                                                <div class="me-2">
                                                                    <img class="rounded-circle"
                                                                        src="{{ asset('storage/' . $courrier->employes->photo) }}"
                                                                        alt="Avatar" width="40" height="40">
                                                                </div>
                                                                <div>
                                                                    <small class="text-muted">Nom:
                                                                        {{ $courrier->employes->nom }}</small><br>
                                                                    <small class="text-muted">Prénom:
                                                                        {{ $courrier->employes->prenom }}</small>
                                                                </div>
                                                            @else
                                                                <small class="text-muted">Aucun employé associé.</small>
                                                            @endif
                                                        </div>
                                                        <div class="d-flex justify-content-between align-items-center">
                                                            <div class="w-100 me-2">
                                                                <a href="{{ url('/courrier/' . $courrier->id . '/accepter') }}"
                                                                    class="btn btn-success btn-sm me-1">
                                                                    <i class="bx bx-check"></i>
                                                                </a>
                                                                <a href="{{ url('/courrier/' . $courrier->id . '/refuser') }}"
                                                                    class="btn btn-danger btn-sm">
                                                                    <i class="bx bx-x"></i>
                                                                </a>

                                                            </div>
                                                            <div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                            @endforeach
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!--/ courriers -->
                            <!-- Présentation de l'entreprise -->
                            <div class="col-md-7 col-lg-7 mb-4 mb-md-0">
                                <div class="card h-100 shadow-lg">
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <div class="d-flex align-items-center">
                                            <img src="{{ asset('/images/logoGam.png') }}" class="rounded-circle me-3"
                                                width="54" alt="Logo GAM Gabon" />
                                            <div class="card-title">
                                                <h5 class="mb-0">GAM Gabon</h5>
                                                <small class="text-muted">Votre createur de solution
                                                    intélligente</small>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="mb-4">
                                            <h6 class="fw-bold">Historique</h6>
                                            <p>Fondée en 2017 par M. MICHAUD Guy Noel, GAM GABON s'engage à offrir des
                                                solutions novatrices dans les Technologies de l’Information et de la
                                                Communication. Grâce à une équipe qualifiée, l'entreprise est devenue un
                                                acteur majeur dans l'intégration de solutions numériques à haute valeur
                                                ajoutée dans les mobiles money.</p>
                                        </div>
                                        <div class="mb-4">
                                            <h6 class="fw-bold">Localisation</h6>
                                            <p>GAM GABON est située à Libreville, Gabon, dans les TERRASSES DE
                                                L’ESTUAIRE. Voici les détails :</p>
                                        </div>

                                        <div class="services-section mb-4">
                                            <h6 class="fw-bold">Services Offerts</h6>
                                            <p>Opérant sur l'ensemble du territoire national via sa plateforme web et
                                                mobile, <strong>GamPay</strong> est optimisée pour une utilisation sur
                                                smartphone.</p>

                                            <h6 class="fw-bold">Axes de Services</h6>
                                            <p>Les services de GAM GABON se divisent en deux axes principaux : solutions
                                                numériques et communication digitale, offrant des outils indispensables
                                                dans la téléphonie mobile et le mobile money.</p>

                                            <h6 class="fw-bold">Liste des Services :</h6>
                                            <ul class="list-unstyled">
                                                <li><strong>ACHATS CREDITS</strong> : Achetez du crédit facilement.</li>
                                                <li><strong>FORFAITS</strong> : Achetez des datas internet depuis votre
                                                    smartphone.</li>
                                                <li><strong>EDAN</strong> : Unités Edan avec carte bancaire ou mobile
                                                    money.</li>
                                                <li><strong>VISA</strong> : Rechargez vos cartes prépayées via
                                                    l'application.</li>
                                                <li><strong>RENDU MONNAIE</strong> : Rendez de l'argent en crédit ou
                                                    mobile money.</li>
                                                <li><strong>RECHARGE</strong> : Recharger votre mobile money facilement.
                                                </li>
                                                <li><strong>CHALENGE</strong> : Participez aux challenges et gagnez des
                                                    prix.</li>
                                                <li><strong>PARIER</strong> : Tickets PMUG et rechargez 1xbet.</li>
                                                <li><strong>TRANSFERT</strong> : Transférez de l'argent à vos proches.
                                                </li>
                                                <li><strong>MES CLIENTS</strong> : Gérez vos statistiques et clients.
                                                </li>
                                                <li><strong>RECLAMATIONS</strong> : Suivez vos réclamations facilement.
                                                </li>
                                                <li><strong>E-COMMERCE</strong> : Achetez des produits en ligne.</li>
                                                <li><strong>Gam TV</strong> : Accédez à des films et séries, créez un
                                                    compte Netflix.</li>
                                                <li><strong>VOYAGE</strong> : Réservez vos billets de transport.</li>
                                                <li><strong>GAM MAP</strong> : Recherchez des lieux et gérez des biens
                                                    immobiliers.</li>
                                            </ul>
                                        </div>
                                        <!-- Avancement -->
                                        <div class="mb-4">
                                            <span class="text-nowrap d-block mb-1">Avancement de l'entreprise</span>
                                            <div class="progress w-100 mb-3" style="height: 8px">
                                                <div class="progress-bar bg-success" role="progressbar"
                                                    style="width: 80%" aria-valuenow="80" aria-valuemin="0"
                                                    aria-valuemax="100"></div>
                                            </div>
                                        </div>
                                        <p>Notre objectif est de fournir des solutions de gestion de projets qui
                                            permettent à nos clients d'atteindre leurs objectifs de manière efficace et
                                            durable.</p>
                                    </div>
                                    <div class="card-footer border-top">
                                        <ul class="list-inline mb-0">
                                            <li class="list-inline-item"><i class="bx bx-phone"></i> Téléphone : (+241)
                                                074 47 18 92, 074 08 41 84</li>
                                            <li class="list-inline-item"><i class="bx bx-mail-send"></i> E-mail : <a
                                                    href="mailto:gamgabon@gmail.com">gamgabon@gmail.com</a></li>
                                            <li class="list-inline-item"><i class="bx bx-world"></i> Site web : <a
                                                    href="https://www.gampay.app/" target="_blank">gampay.app</a></li>
                                            <li class="list-inline-item"><i class="bx bx-logo-facebook"></i> Facebook :
                                                Gam GABON</li>
                                            <li class="list-inline-item"><i class="bx bx-logo-instagram"></i> Instagram
                                                : Gam GABON</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!-- Présentation de l'entreprise -->
                            <!-- fin des contrats -->
                            <div class="col-md-5 col-lg-5 mb-0">
                                <div class="card">
                                    <div class="card-header text-white"
                                        style="background-color:#004e98; text-align:center;">
                                        <h5 class="card-title mb-0" style="color:white">Contrats en cours de fin</h5>
                                    </div>
                                    <br>

                                    <div class="card-body">
                                        <ul class="timeline">
                                            @foreach ($employes as $employe)
                                                <li
                                                    class="timeline-item timeline-item-transparent d-flex align-items-start ps-4">
                                                    <span class="timeline-point timeline-point-primary me-3"></span>
                                                    <img src="{{ asset('storage/' . $employe->photo) }}"
                                                        alt="Photo de {{ $employe->nom }}" class="rounded-circle"
                                                        width="60" />
                                                    <div>
                                                        <h6 class="mb-1 text-dark">{{ $employe->nom }}</h6>
                                                        @foreach ($employe->contrats as $contrat)
                                                            <small class="text-muted d-block">
                                                                <strong>Date de Fin de Contrat:</strong> <span
                                                                    class="text-dark">{{ $contrat->date_fin_contrat }}</span>
                                                            </small>
                                                            <small class="text-muted d-block">
                                                                <strong>Type de Contrat:</strong> <span
                                                                    class="text-dark">{{ $contrat->type_contrat }}</span>
                                                            </small>
                                                        @endforeach
                                                    </div>
                                                </li>
                                                <a href="{{ url('/formAvenant/' . $employe->id . '/courrier') }}"
                                                    class="btn btn-primary text-nowrap">
                                                    <i class="bx bx-user-check"></i> envoyer un Avenant
                                                </a>
                                                <hr>
                                            @endforeach
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!--/ fin des contrats -->
                        </div>
                    </div>
                    <!-- / Content -->


                </div>
            </div>
        </div>
    </div>
</x-app-layout>