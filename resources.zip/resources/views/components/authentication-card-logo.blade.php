<img src="{{ asset('images/logoGam.png')}}"  style= "widht:100px; height:100px;" >
