<div>
    <div class="d-flex align-items-center gap-2 w-100">
        <input type="text"  wire:model.live="search" class="form-control" placeholder="Rechercher un employé..." aria-label="Rechercher" style="width: 300px;" />
    </div>

    <ul>
        @if(count($employes) > 0)
            <div class="row g-4">
            @foreach($employes as $employe)
                <div class="col-xl-4 col-lg-6 col-md-6">
                    <div class="card">
                        <div class="card-body text-center">
                           

                            <div class="mx-auto mb-3">
                                <img src="{{ asset('storage/' . $employe->photo) }}" alt="Avatar Image"
                                    class="rounded-circle w-px-100" />
                            </div>

                            <h5 class="mb-1 card-title">{{ $employe->nom }}</h5>
                            <span>{{ $employe->profession }}</span>

                            <div class="d-flex align-items-center justify-content-center my-3 gap-2">
                                <a href="javascript:;" class="me-1"><span class="badge bg-label-secondary">{{ $employe->departement }}</span></a>
                                <a href="javascript:;"><span class="badge bg-label-warning">{{ $employe->service }}</span></a>
                            </div>

                            <div class="d-flex align-items-center justify-content-around my-4 py-2">
                                <div>
                                    <h4 class="mb-1">{{$employe->contrats_count}}</h4>
                                    <span>contrats</span>
                                  
                                </div>
                                <div>
                                    <h4 class="mb-1">{{ $employe->fiche_de_paies_count}}</h4>
                                    <span>remuneration</span>
                                </div>
                                <div>
                                    <h4 class="mb-1">{{ $employe->courriers_count}}</h4>
                                    <span>courrier</span>
                                </div>
                            </div>

                            <div class="d-flex align-items-center justify-content-center">
                                <a href="{{ url('/formulaireAjoutSanction/' . $employe->id . '/courrier') }}"
                                    class="btn btn-label-secondary btn-icon me-2">
                                    <i class="bx bx-envelope"></i>
                                </a>
                                <a href="{{ url('/employe/' . $employe->id . '/archiver') }}"
                                    class="btn btn-label-secondary btn-icon me-2">
                                    <i class="bx bx-archive"></i>
                                </a>
                                <a href="{{ url('/formulaireAjout/' . $employe->id . '/remunerer') }}"
                                    class="btn btn-label-secondary btn-icon me-2">
                                    <i class="bx bx-calculator"></i>
                                </a>
                                <a href="{{ url('/employe/' . $employe->id . '/editer') }}"
                                    class="btn btn-label-secondary btn-icon me-2">
                                    <i class="bx bxs-edit"></i>
                                </a>
                                <a href="{{ url('/consulter/' . $employe->id . '/consulter') }}"
                                    class="btn btn-label-secondary btn-icon">
                                    <i class="bx bx-news"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
        @else
            <li>Aucun employé trouvé.</li>
        @endif
    </ul>
</div>