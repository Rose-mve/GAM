@extends('layouts.admin')

@section('title', 'Envoyer un courrier')

@section('content')

<div class="row">
    <!-- Basic Layout -->
    <div class="col-xxl">
        <div class="card mb-4">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h4>Envoyer un Avenant à l'employé {{ $employe->nom }}</h4>
            </div>
            <div class="card-body">
                <form action="{{ url('/avenant') }}" method="POST" enctype="multipart/form-data">
                @csrf
                    <div class="mb-3 row">
                        <label for="date_du_courrier" class="col-md-2 col-form-label">Date du Courrier</label>
                        <div class="col-md-10">
                            <input class="form-control" type="date" id="date_du_courrier" name="date_du_courrier"
                                required />
                            @error('date_du_courrier')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="mb-3 row" hidden>
                        <label class="col-sm-2 col-form-label" for="type_de_courrier" hidden>Type de Courrier</label>
                        <div class="col-sm-10" hidden>
                            <select id="type_de_courrier" class="form-select" name="type_de_courrier" required value="Avenant" hidden>
                                <option value="Sanction">Sanction</option>
                                <option value="Avenant">Avenant</option>
                                <option value="Demande d'explication">Demande d'explication</option>
                            </select>
                            @error('type_de_courrier')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>

                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="motif">Note</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="motif" placeholder="Note"
                                name="motif"  />
                            @error('motif')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <input type="hidden" name="id_employe" value="{{ $employe->id }}">

                    <div class="row justify-content-end">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">envoyer</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>




@endsection