@extends('layouts.admin')

@section('title', 'Envoyer un courrier')

@section('content')

<div class="row">
    <!-- Basic Layout -->
    <div class="col-xxl">
        <div class="card mb-4">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h2>Envoyer un courrier a l'employé {{ $employe->nom }}</h2>

            </div>
            <div class="card-body">
                <form action="{{ url('/sanction') }}" method="POST" enctype="multipart/form-data">
                @csrf
                    <div class="mb-3 row">
                        <label for="date_du_courrier" class="col-md-2 col-form-label">Date du Courrier</label>
                        <div class="col-md-10">
                            <input class="form-control" type="date" id="date_du_courrier" name="date_du_courrier"
                                required />
                            @error('date_du_courrier')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label" for="type_de_courrier">Type de Courrier</label>
                        <div class="col-sm-10">
                            <select id="type_de_courrier" class="form-select" name="type_de_courrier" required>
                                <option value="Sanction">Sanction</option>
                                <option value="Avenant">Avenant</option>
                                <option value="Demande d'explication">Demande d'explication</option>
                            </select>
                            @error('type_de_courrier')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>

                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="motif">motif</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="motif" placeholder="motif"
                                name="motif"  />
                            @error('motif')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label" for="type_de_sanction">Type de Sanction</label>
                        <div class="col-sm-10">
                            <select id="type_de_sanction" class="form-select" name="type_de_sanction">
                                <option value="">Sélectionnez</option>
                                <option value="Avertissement">Avertissement</option>
                                <option value="Blâme">Blâme</option>
                                <option value="Suspension">Suspension</option>
                                <option value="Licenciement">Licenciement</option>
                            </select>
                            @error('type_de_sanction')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>

                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="mesure_corrective">Mesure Corrective</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="mesure_corrective"
                                placeholder="mesure" name="mesure_corrective"  />
                            @error('mesure_corrective')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <input type="hidden" name="id_employe" value="{{ $employe->id }}">

                    <div class="row justify-content-end">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">envoyer</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>




@endsection