@extends('layouts.admin')

@section('title', 'Ajouter un bulletin de paie')

@section('content')

<h5 class="my-4">Rémunérer l'employé {{ $employe->nom }}</h5>
<form action="{{ url('/creerFiche_de_paie') }}" method="POST">
    @csrf
    <div class="row g-1">
        <input type="hidden" name="id_employe" value="{{ $employe->id }}">

        <!-- Mois -->
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label" for="mois">Mois</label>
                <select id="mois" name="mois" class="form-select" required>
                    <option value="" disabled selected>Choisir un mois</option>
                    <option value="Janvier">Janvier</option>
                    <option value="Février">Février</option>
                    <option value="Mars">Mars</option>
                    <option value="Avril">Avril</option>
                    <option value="Mai">Mai</option>
                    <option value="Juin">Juin</option>
                    <option value="Juillet">Juillet</option>
                    <option value="Août">Août</option>
                    <option value="Septembre">Septembre</option>
                    <option value="Octobre">Octobre</option>
                    <option value="Novembre">Novembre</option>
                    <option value="Décembre">Décembre</option>
                </select>
            </div>
        </div>
        <!-- Période de début -->
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label" for="periode_debut">Du</label>
                <input type="date" id="periode_debut" name="periode_debut" class="form-control" required />
            </div>
        </div>
        <!-- Période de fin -->
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label" for="periode_fin">Au</label>
                <input type="date" id="periode_fin" name="periode_fin" class="form-control" required />
            </div>
        </div>



        <!-- Salaire brut -->

        <input type="hidden" id="salaire_brut" name="salaire_brut" class="form-control" placeholder="0" />

        <!-- Primes -->
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label" for="primes">Primes</label>
                <input type="number" id="primes" name="primes" class="form-control" placeholder="0" />
            </div>
        </div>

        <!-- Prélèvement CNSS -->

        <input type="hidden" id="precompte_cnss" name="precompte_cnss" class="form-control" placeholder="0" />

        <!-- Prélèvement CNAMGS -->


        <input type="hidden" id="precompte_cnamgs" name="precompte_cnamgs" class="form-control" placeholder="0" />


        <!-- Indemnités -->
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label" for="indemnites">Indemnités</label>
                <input type="number" id="indemnites" name="indemnites" class="form-control" placeholder="0" />
            </div>
        </div>

        <!-- Salaire net -->

        <input type="hidden" id="salaire_net" name="salaire_net" class="form-control" placeholder="0" />



        <!-- Statut -->

        <input type="hidden" id="statut" name="statut" class="form-control" placeholder="Actif" />


        <!-- Mode de paiement -->
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label" for="mode_de_paiement">Mode de Paiement</label>
                <select id="mode_de_paiement" name="mode_de_paiement" class="form-select">
                    <option value="Carte">Carte</option>
                    <option value="Cash">Espèces</option>
                    <option value="Virement">Virement</option>
                    <option value="Virement">GAMpay</option>
                </select>
            </div>
        </div>

        <!-- Date de paiement -->
        <div class="col-md-6">
            <div class="mb-3">
                <label class="form-label" for="date_de_paiement">Date de Paiement</label>
                <input type="date" id="date_de_paiement" name="date_de_paiement" class="form-control" />
            </div>
        </div>
    </div>

    <div class="mb-3">
        <button type="submit" class="btn btn-primary">Enregistrer</button>
    </div>
</form>

@endsection