<x-guest-layout>
    <x-authentication-card>
        <x-slot name="logo">
            <x-authentication-card-logo />
        </x-slot>

        <x-validation-errors class="mb-4" />

        @session('status')
            <div class="mb-4 font-medium text-sm text-green-600">
                {{ $value }}
            </div>
        @endsession

        <form method="POST" action="{{ route('login') }}">
            @csrf

            <div class="mb-4">
                <x-label for="email" value="{{ __('Email') }}" class="font-semibold text-lg" />
                <x-input id="email" class="block mt-1 w-full border rounded-lg p-2 focus:outline-none focus:ring focus:ring-indigo-300" type="email" name="email" :value="old('email')" required autofocus autocomplete="username" />
            </div>

            <div class="mb-4">
                <x-label for="password" value="{{ __('mot de passe') }}" class="font-semibold text-lg" />
                <x-input id="password" class="block mt-1 w-full border rounded-lg p-2 focus:outline-none focus:ring focus:ring-indigo-300" type="password" name="password" required autocomplete="current-password" />
            </div>

            <div class="flex items-center justify-between mt-4">
              

                @if (Route::has('password.request'))
                    <a class="text-sm text-gray-600 hover:text-gray-900" href="{{ route('password.request') }}">
                        {{ __('mot de passe oublié?') }}
                    </a>
                @endif
            </div>

            <div class="flex justify-center mt-6">
                <x-button class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-lg">
                    {{ __('connexion') }}
                </x-button>
            </div>
        </form>
    </x-authentication-card>
</x-guest-layout>