@extends('layouts.admin')

@section('title', 'consulter')

@section('content')


<div class="row g-4">
  <div class="row">

    <div class="col-12">
      <div class="card mb-4">
        <div class="user-profile-header-banner">
          <img src="../../assets/img/pages/profile-banner.png" alt="Banner image" class="rounded-top" />
        </div>
        <div class="user-profile-header d-flex flex-column flex-sm-row text-sm-start text-center mb-4">
          <div class="flex-shrink-0 mt-n2 mx-sm-0 mx-auto">
            <img src="{{ asset('storage/' . $employee->photo) }}"
              class="d-block h-auto ms-0 ms-sm-4 rounded-3 user-profile-img" />
          </div>
          <div class="flex-grow-1 mt-3 mt-sm-5">
            <div
              class="d-flex align-items-md-end align-items-sm-start align-items-center justify-content-md-between justify-content-start mx-4 flex-md-row flex-column gap-4">
              <div class="user-profile-info">
                <h4>{{$employee->nom . ' ' . $employee->prenom}}</h4>
              </div>
              <a href="{{ url('/employe/' . $employee->id . '/archiver') }}" class="btn btn-primary text-nowrap">
                <i class="bx bx-user-check"></i> archiver
              </a>
              <a href="{{ url('/formulaireAjout/' . $employee->id . '/remunerer') }}"
                class="btn btn-primary text-nowrap">
                <i class="bx bx-user-check"></i> remunerer
              </a>
              <a href="{{ url('/formulaireAjoutSanction/' . $employee->id . '/courrier') }}"
                class="btn btn-primary text-nowrap">
                <i class="bx bx-user-check"></i> envoyer un courrier
              </a>

            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
  <!--/ Header -->

  <div class="col-xl-4 col-lg-5 col-md-2">


    <!-- About User -->
    <div class="card mb-4">
      <div class="card-body">
        <small class="text-muted text-uppercase">Information</small>
        <ul class="list-unstyled mb-4 mt-3">
          <li class="d-flex align-items-center mb-3">
            <i class="bx bx-user text-success"></i><span class="fw-semibold mx-2">Nom et prenom:</span>
            <span>{{ $employee->nom }}</span>
          </li>
          <li class="d-flex align-items-center mb-3">
            <i class="bx bx-check text-danger"></i><span class="fw-semibold mx-2">genre:</span> <span>{{  $employee->genre }}</span>
          </li>
          <li class="d-flex align-items-center mb-3">
            <i class="bx bx-star text-warning"></i><span class="fw-semibold mx-2">profession:</span>
            <span>{{ $employee->profession }}</span>
          </li>
        </ul>
        <small class="text-muted text-uppercase">Contacts</small>
        <ul class="list-unstyled mb-4 mt-3">
          <li class="d-flex align-items-center mb-3">
            <i class="bx bx-phone text-primary"></i><span class="fw-semibold mx-2">Contact:</span>
            <span>{{$employee->tel }}</span>
          </li>
          <li class="d-flex align-items-center mb-3">
            <i class="bx bx-envelope text-black"></i><span class="fw-semibold mx-2">Email:</span>
            <span>j{{$employee->email}}</span>
          </li>
        </ul>
        <small class="text-muted text-uppercase">Contrat</small>
        <ul class="list-unstyled mt-3 mb-0">
          <li class="d-flex align-items-center mb-3">
            <i class="bx bx-calendar-alt -text-info me-2"></i>
            <div class="d-flex flex-wrap">
              <span class="fw-semibold me-2">date de debut du contrat
              </span><span>{{ $infocontrat[0]['date_debut_contrat'] }}</span>
            </div>
          </li>
          <li class="d-flex align-items-center">
            <i class="bx bx-calendar-alt text-info me-2"></i>
            <div class="d-flex flex-wrap">
              <span class="fw-semibold me-2">Date de fin du contrat
              </span><span>{{ $infocontrat[0]['date_fin_contrat']}}</span>
            </div>
          </li>
          <li class="d-flex align-items-center">
            <i class="bx bxs-file text-info me-2"></i>
            <div class="d-flex flex-wrap">
              <span class="fw-semibold me-2">type de contrat : </span><span>{{ $infocontrat[0]['type_contrat']}}</span>
            </div>
          </li>
          <li class="d-flex align-items-center">
            <i class="fas fa-mail-bulk text-info me-2"></i>
            <div class="d-flex flex-wrap">
              <span class="fw-semibold me-2">Salaire : </span><span>{{ $infocontrat[0]['salaire']}}</span>
            </div>
          </li>
        </ul>
      </div>
    </div>
  
    <!--/ Profile Overview -->
  </div>
  <div class="col-xl-8 col-lg-7 col-md-7">
    <!-- Contrat -->
    <div class="card card-action mb-4">
      <div class="card-header align-items-center">
        <h5 class="card-action-title mb-0"><i class="bx bx-list-ul bx-sm me-2"></i>contrats</h5>
        <div class="card-action-element btn-pinned">

        </div>
      </div>
      <div class="card-body">
        <ul class="timeline ms-2">
          @foreach($employee->contrats as $contrat)
        <li class="timeline-item timeline-item-transparent">
        <span class="timeline-point timeline-point-warning"></span>
        <div class="timeline-event">
          <div class="timeline-header mb-1">
          <h6 class="mb-0">type de contrat :{{ $contrat->type_contrat }}</h6>
          <small class="text-muted"> date de debut:{{ $contrat->date_debut_contrat }}</small>
          </div>
          <p class="mb-2">Date de fin :{{ $contrat->date_fin_contrat }}</p>
          <div class="d-flex flex-wrap">
          <div class="avatar me-3">
            <img src="{{ asset('images/pdf.png') }}" alt="Avatar" style="widht:50px; height: 50px;" />
          </div>
          <div>
            <a href="{{ route('telecharger_contrat', $contrat->id) }}" class="btn btn-primary">
           <i class="bx bxs-download"></i>
            </a>

          </div>
          </div>
        </div>
        </li>
      @endforeach
        </ul>
      </div>
    </div>
    <!--/ Activity Timeline -->
    <div class="row">
      <!-- courriers -->
      <div class="col-lg-12 col-xl-6">
        <div class="card card-action mb-4">
          <div class="card-header align-items-center">
            <h5 class="card-action-title mb-0">courriers</h5>
          </div>
          <div class="card-body">
            <ul class="list-unstyled mb-0">
              @foreach($employee->courriers as $courrier)
          <li class="mb-3">
          <div class="d-flex align-items-start">
            <div class="d-flex align-items-start">
            <div class="avatar me-3">
              <img src="../../assets/img/avatars/2.png" alt="Avatar" class="rounded-circle" />
            </div>
            <div class="me-2">
              <h6 class="mb-0">{{ $courrier->type_de_courrier }}</h6>
              <small class="text-muted">{{ $courrier->date_du_courrier }}</small>
            </div>
            </div>
            <div class="ms-auto">
            </div>
            <div class="ms-auto">
            <button class="btn btn-label-primary p-1 btn-sm" diseable><i
              class="bx bx-status"></i>{{ $courrier->statut }}</button>
            </div>
          </div>
          </li>
        @endforeach
            </ul>
          </div>
        </div>
      </div>
      <!--/ courriers -->
      <!-- bulletin de paie -->
      <div class="col-lg-12 col-xl-6">
        <div class="card card-action mb-4">
          <div class="card-header">
            <h5 class="card-title mb-0">Bulletins de Paie</h5>
          </div>
          <div class="card-body">
            <ul class="list-unstyled mb-0">
              @foreach($employee->fiche_de_paies as $Fiche_de_paie)
          <li class="mb-4 p-3 border rounded bg-light shadow-sm">
          <div class="d-flex align-items-center">
            <div class="me-3">
            <i class="bi bi-calendar date-icon fs-5 text-primary"></i>
            </div>
            <div class="flex-grow-4">
            <small class="mb-1 text-muted"><i
              class="bx bx-calendar-alt"></i>Mois:{{ $Fiche_de_paie->mois }}</small>
            <small class="mb-1 text-muted">Du:{{ $Fiche_de_paie->periode_debut }}</small>
            <small class="mb-1 text-muted">Au:{{ $Fiche_de_paie->periode_fin}}</small>
            <h6 class="mb-1">Salaire net : {{ $Fiche_de_paie->salaire_net }}</h6>
            </div>
            <div class="text-end">
            <a href="{{ route('fiche_de_paie.affiche', $Fiche_de_paie->id) }}" class="btn btn-primary mt-2">
              <i class="bx bx-news"></i>
            </a>
            </div>
          </div>
          </li>
        @endforeach
            </ul>
          </div>
        </div>
      </div>
      <!-- /bulletin de paie -->

    </div>
  </div>

</div>




@endsection