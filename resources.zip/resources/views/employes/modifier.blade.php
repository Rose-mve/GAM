@extends('layouts.admin')

@section('title', 'modifier employe')

@section('content')



<div class="row">
    <!-- Basic Layout -->
    <div class="col-xxl">
        <div class="card mb-4">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h2>Modifier un Employé</h2>

            </div>
            <div class="card-body">
                <form action="{{ url('/employe/' . $employe->id . '/modifier_employe') }}" method="POST"
                    enctype="multipart/form-data">
                    @csrf
                    @method('PUT')
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="nom">Nom</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nom" value="{{ old('nom', $employe->nom) }}" name="nom"
                               disabled/>
                            @error('nom')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="prenom">prenom</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="prenom" placeholder="entrez le prénom"
                                name="prenom" disabled value="{{ old('prenom', $employe->prenom) }}" />
                            @error('prenom')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label">genre</label>
                        <div class="col-sm-9">
                            <div class="form-check mb-2">
                                <input name="genre" class="form-check-input" type="radio" value="masculin" id="masculin"
                                    checked=""   value="{{ old('genre', $employe->genre) }}" disabled/>
                                <label class="form-check-label" for="collapsible-addressType-home">
                                    masculin
                                </label>
                                @error('genre')
                                    <div class="error">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="form-check">
                                <input name="genre" class="form-check-input" type="radio" value="feminin"
                                    id="feminin" disabled /> <label class="form-check-label" for="genre" >

                                    feminin
                                </label>
                                @error('genre')
                                    <div class="error">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label" for="profession">proféssion</label>
                        <div class="col-sm-10">
                            <select id="profession" class="form-select" name="profession" name="profession" value="{{ old('profession', $employe->profession) }}" disabled>
                                <option value="chef de service">Chef de service</option>
                                <option value="Agent">Agent</option>
                                <option value="stagiaire">Stagiaire</option>
                            </select>
                            @error('profession')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>

                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label" for="departement">Département</label>
                        <div class="col-sm-10">
                            <select id="departement" class="form-select" name="departement" name="profession" value="{{ old('profession', $employe->departement) }}" disabled>
                                <option value="produit_digitaux">Produit Digitaux</option>
                                <option value="sigma">Sigma</option>
                                <option value="it">It</option>
                                <option value="international & marketing">International & marketing</option>
                            </select>
                            @error('departement')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>

                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label" for="service">Service</label>
                        <div class="col-sm-10">
                            <select id="service" class="form-select" name="service" value="{{ old('profession', $employe->service) }}" disabled>
                                <option value="mission zone B">Mission zone B</option>
                                <option value="assistance rapproche">assistance rapproché</option>
                                <option value="mission zone A">Mission zone A</option>
                                <option value=" design et production">design et production</option>
                                <option value=" recherche et developement"> recherche et developement</option>
                                <option value=" international"> international</option>
                                <option value=" marketing"> marketing</option>
                            </select>
                            @error('service')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>

                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="numcnss">N°CNSS</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="numcnss" name="numcnss"  value="{{ old('profession', $employe->numcnss) }}"
                                placeholder="numcnss."  disabled/>
                            @error('numcnss')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="tel">tel</label>
                        <div class="col-sm-10">
                            <input type="text" id="tel" class="form-control phone-mask" placeholder="+241"
                                aria-label="+241" aria-describedby="basic-default-phone" name="tel"  value="{{ old('profession', $employe->tel) }}"  disabled/>
                            @error('tel')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-2 col-form-label" for="email">Email</label>
                        <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                                <input type="email" id="email" class="form-control" placeholder="email" value="{{ old('email', $employe->email) }}"
                                    aria-label="email" aria-describedby="basic-default-email2" name="email" disabled />
                                @error('email')
                                    <div class="error">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card mb-4">
                            <h5 class="card-header">Photo</h5>
                            <div class="card-body">
                                <div class="dz-message needsclick">
                                    clicker ici pour telecharger l'image
                                </div>
                                <div class="fallback">
                                    <input type="file" id="photo" name="photo" value="{{ old('photo', $employe->photo) }}" />
                                    @error('photo')
                                        <div class="error">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="date_debut_contrat" class="col-md-2 col-form-label">Date de Debut du contrat</label>
                        <div class="col-md-10">
                            <input class="form-control" type="date" id="date_debut_contrat" name="date_debut_contrat"
                                required />
                            @error('date_debut_contrat')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="date_embauche" class="col-md-2 col-form-label">Date d'embauche</label>
                        <div class="col-md-10">
                            <input class="form-control" type="date" id="date_embauche" name="date_embauche"
                                required />
                            @error('date_embauche')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="date_fin_contrat" class="col-md-2 col-form-label">Date de fin du contrat</label>
                        <div class="col-md-10">
                            <input class="form-control" type="date" id="date_fin_contrat" name="date_fin_contrat"
                                required />
                            @error('date_fin_contrat')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label class="col-sm-2 col-form-label" for="type_contrat">Type de Contrat </label>
                        <div class="col-sm-10">
                            <select id="type_contrat" class="form-select" name="type_contrat">
                                <option value="CDD">CDD</option>
                                <option value="CDI">CDI</option>
                                <option value="Stage_ecole">Stage Ecole</option>
                                <option value="Stage_travail">Stage Travail</option>
                            </select>
                            @error('type_contrat')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>

                    </div>
                    <div class="mb-3 row">
                        <label for="salaire" class="col-md-2 col-form-label">Salaire</label>
                        <div class="col-md-10">
                            <input class="form-control" type="number" id="salaire" placeholder="1000000"
                                name="salaire" />
                            @error('salaire')
                                <div class="error">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card mb-4">
                            <h5 class="card-header">fichier du contrat</h5>
                            <div class="card-body">
                                <div class="dz-message needsclick">
                                    clicker ici pour telecharger le fichier du contrat
                                </div>
                                <div class="fallback">
                                    <input type="file" id="contrat_pdf" name="contrat_pdf" />
                                    @error('contrat_pdf')
                                        <div class="error">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-end">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">Modifier</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>





@endsection